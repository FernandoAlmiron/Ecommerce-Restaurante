package org.example.web.cliente;

import org.example.Modelo.enums.EstadoEnvio;
import org.example.Modelo.persona.Cliente;
import org.example.Modelo.reserva.Envio;
import org.example.Modelo.reserva.Reserva;
import org.example.service.persona.ClienteService;
import org.example.service.reserva.EnvioService;
import org.example.service.reserva.ReservaService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Comparator;
import java.util.List;

@Controller
public class ClientePerfilController {

    private static final int ULTIMOS = 3;   // cuántos pedidos y reservas se muestran en "Mi cuenta"

    private final ClienteService clienteService;
    private final EnvioService envioService;
    private final ReservaService reservaService;

    public ClientePerfilController(ClienteService clienteService, EnvioService envioService,
                                   ReservaService reservaService) {
        this.clienteService = clienteService;
        this.envioService = envioService;
        this.reservaService = reservaService;
    }

    // "Mi cuenta": el pedido en marcha, los últimos pedidos, las últimas reservas y los datos
    @GetMapping("/perfil")
    public String perfil(Authentication auth, Model model) {
        Cliente cliente = clienteService.buscarPorUsername(auth.getName());

        // los más nuevos primero
        List<Envio> envios = envioService.listarPorCliente(cliente.getIdCliente()).stream()
                .sorted(Comparator.comparing(Envio::getIdEnvio).reversed())
                .toList();
        Envio enCurso = envios.stream()
                .filter(e -> e.getEstado() == EstadoEnvio.PENDIENTE || e.getEstado() == EstadoEnvio.EN_CAMINO)
                .findFirst()
                .orElse(null);
        List<Envio> anteriores = envios.stream().filter(e -> e != enCurso).toList();

        List<Reserva> reservas = reservaService.listarPorCliente(cliente.getIdCliente()).stream()
                .sorted(Comparator.comparing(Reserva::getFechaReserva)
                        .thenComparing(Reserva::getHoraReserva).reversed())
                .toList();

        model.addAttribute("c", cliente);
        model.addAttribute("enCurso", enCurso);
        model.addAttribute("envios", anteriores.stream().limit(ULTIMOS).toList());
        model.addAttribute("hayMasPedidos", anteriores.size() > ULTIMOS);
        model.addAttribute("reservas", reservas.stream().limit(ULTIMOS).toList());
        model.addAttribute("hayMasReservas", reservas.size() > ULTIMOS);
        return "cliente/perfil";
    }
}
